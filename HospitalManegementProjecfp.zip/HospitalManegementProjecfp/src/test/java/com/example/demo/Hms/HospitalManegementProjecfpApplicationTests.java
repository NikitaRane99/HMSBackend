package com.example.demo.Hms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalManegementProjecfpApplicationTests {

	@Test
	void contextLoads() {
	}

}
