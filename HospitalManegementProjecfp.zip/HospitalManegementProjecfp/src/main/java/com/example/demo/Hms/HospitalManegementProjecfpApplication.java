package com.example.demo.Hms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalManegementProjecfpApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalManegementProjecfpApplication.class, args);
	}

}
